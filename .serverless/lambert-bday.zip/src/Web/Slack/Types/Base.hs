module Web.Slack.Types.Base where

import Data.Text (Text)

type URL = Text
