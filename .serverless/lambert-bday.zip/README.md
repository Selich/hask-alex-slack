# Lambert

Lambert-bday is a part of LambdaWorks Slack bot used to view or add users birthdays

## Requirements

- [Install stack](https://docs.haskellstack.org/en/stable/README/) framework.

## Deployment

```bash
stack build
stack run
```
